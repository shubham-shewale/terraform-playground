import boto3
import json
import os
from datetime import datetime
import uuid

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(os.environ['DYNAMODB_TABLE'])
sns = boto3.client('sns')
sns_topic_arn = os.environ['SNS_TOPIC_ARN']

def lambda_handler(event, context):
    findings = []

    # Scan security groups
    ec2 = boto3.client('ec2')
    sgs = ec2.describe_security_groups()['SecurityGroups']
    for sg in sgs:
        for rule in sg['IpPermissions']:
            if 'IpRanges' in rule:
                for ip_range in rule['IpRanges']:
                    if ip_range['CidrIp'] == '0.0.0.0/0':
                        finding = {
                            'id': str(uuid.uuid4()),
                            'resource_type': 'SecurityGroup',
                            'resource_id': sg['GroupId'],
                            'issue': 'Open to all IPs',
                            'severity': 'High',
                            'timestamp': datetime.utcnow().isoformat()
                        }
                        findings.append(finding)

    # Scan S3 buckets
    s3 = boto3.client('s3')
    buckets = s3.list_buckets()['Buckets']
    for bucket in buckets:
        try:
            public_access = s3.get_public_access_block(Bucket=bucket['Name'])
            if not public_access['PublicAccessBlockConfiguration']['BlockPublicAcls']:
                finding = {
                    'id': str(uuid.uuid4()),
                    'resource_type': 'S3Bucket',
                    'resource_id': bucket['Name'],
                    'issue': 'Public access not blocked',
                    'severity': 'High',
                    'timestamp': datetime.utcnow().isoformat()
                }
                findings.append(finding)
        except:
            pass

    # Store findings
    for finding in findings:
        table.put_item(Item=finding)
        if finding['severity'] == 'High':
            sns.publish(
                TopicArn=sns_topic_arn,
                Message=json.dumps(finding),
                Subject='High Severity CSPM Finding'
            )

    return {'statusCode': 200, 'body': json.dumps({'findings': len(findings)})}